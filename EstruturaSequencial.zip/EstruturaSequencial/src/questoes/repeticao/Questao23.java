
package questoes.repeticao;

import java.util.Scanner;

public class Questao23 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite as notas de 0 a 10");
        double nota1;
        double nota2;
        
        do{
            System.out.println("Digite a nota 1");
            nota1 = teclado.nextDouble();
        }while(!(nota1 >= 0 && nota1 <= 10));
        
        do{
            System.out.println("Digite a nota 2");
            nota2 = teclado.nextDouble();
        }while(!(nota2 >= 0 && nota2 <= 10));
        
        double media = (nota1+nota2)/2;
        System.out.println("A média é: "+media);
    }    
}
