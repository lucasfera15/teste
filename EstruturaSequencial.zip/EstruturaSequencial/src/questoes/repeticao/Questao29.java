
package questoes.repeticao;

import java.util.Scanner;

public class Questao29 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int soma = 0;
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Digite o valor "+(i+1));
            soma += teclado.nextInt();
        }
        
        System.out.println("A soma dos números é: "+soma);
    }
}
