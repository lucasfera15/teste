
package questoes.repeticao;

import java.util.Scanner;

public class Questao26 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int n;
        
        do{
        System.out.println("Digite um valor maior que zero");
        n = teclado.nextInt();
        }while(n <= 0);
        
        for (int i = 0; i <= n; i++) {
            System.out.println(i);
        }
    }
}
