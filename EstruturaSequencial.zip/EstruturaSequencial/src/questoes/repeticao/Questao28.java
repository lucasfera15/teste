package questoes.repeticao;

import java.util.Scanner;

public class Questao28 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int valor;
        
        do{
            System.out.println("Digite um valor de 1 a 10");
            valor = teclado.nextInt();
        }while(!(valor >= 1 || valor <= 10));
        
        System.out.println("Tabuada do "+valor);
        for (int i = 1; i <= 10; i++) {
            System.out.println(i*valor);
        }
    }
}
