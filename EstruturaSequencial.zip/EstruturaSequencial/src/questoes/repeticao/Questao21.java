
package questoes.repeticao;

import java.util.Scanner;

public class Questao21 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o valor 1");
        double valor1 = teclado.nextDouble();
        
        System.out.println("Digite o valor 2");
        double valor2 = teclado.nextDouble();
        
        while(valor2 == 0){
            System.out.println("Digite o valor 2 novamente");
            valor2 = teclado.nextDouble();
        }
        
        double divisao = valor1/valor2;
        System.out.println(divisao);
    }
}
