package questoes.repeticao;

import java.util.Scanner;

public class Questao30 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int soma = 0;
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Digite o valor "+(i+1));
            int numeroLido = teclado.nextInt();
            if(numeroLido < 40){
                soma += numeroLido;
            }
        }
        
        System.out.println("A soma dos números é: "+soma);
    }
}
