
package questoes.sequencial;

import java.util.Scanner;

public class Questao02 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digita a base");
        double base = teclado.nextDouble();
        System.out.println("Digita a altura");
        double altura = teclado.nextDouble();
        
        double area = (base * altura)/2;
        System.out.println("A área é: "+area);
    }
 
}
