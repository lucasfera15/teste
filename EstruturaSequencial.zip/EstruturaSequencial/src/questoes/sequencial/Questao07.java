/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao07 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o salário atual");
        double salario = teclado.nextDouble();
        System.out.println("Digite o percentual de reajuste");
        double percentReajsute = teclado.nextDouble();
        
        double reajuste = (salario * percentReajsute) / 100;
        double novoSalario = salario + reajuste;
        
        System.out.println("O novo salário é de: "+novoSalario);
        
    }
}
