/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao05 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite os anos");
        int anos = teclado.nextInt();
        System.out.println("Digite os meses");
        int meses = teclado.nextInt();
        System.out.println("Digite os dias");
        int dias = teclado.nextInt();
        
        int idadeTotal = (anos * 365) + (meses * 30) + dias;
        System.out.println("A idade total expressa em dias é: "+idadeTotal);
    }
}
