
package questoes.sequencial;

import java.util.Scanner;

public class Questao01 {
    public static void main(String[] args) {
             
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a nota 1");
        double nota1 = teclado.nextDouble();
        System.out.println("Digite a nota 2");
        double nota2 = teclado.nextDouble();
        System.out.println("Digite a nota 3");
        double nota3 = teclado.nextDouble();
        
        double media = (nota1+nota2+nota3)/3;
        
        System.out.println("Sua média foi: "+media);      
    }       
}


