/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao10 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a base");
        double base = teclado.nextDouble();
        System.out.println("Digite a altura");
        double altura = teclado.nextDouble();
        
        double area = (base * altura) / 2;
        System.out.println("A área é: "+area);
    }
}
