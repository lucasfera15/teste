/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao04 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite um número");
        int num = teclado.nextInt();
        
        System.out.println("O sucessor de "+num+" é "+ (num +1));
        System.out.println("O antecessor de "+num+" é "+ (num -1));
        
    }
}
