/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

/**
 *
 * @author LUCAS-PC
 */
public class Questao03 {
    public static void main(String[] args) {
        int A = 10;
        int B = 20;
        
        System.out.println("A: "+A);
        System.out.println("B: "+B);
        
        int C = B;
        B = A;
        A = C;
        
        System.out.println("Novo A: "+A);
        System.out.println("Novo B: "+B);
    }
}
