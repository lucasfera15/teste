/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao09 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o número de carros vendidos");
        int carrosVendidos = teclado.nextInt();
        System.out.println("Digite o salário fixo");
        double salarioFixo = teclado.nextDouble();
        System.out.println("Digite o valor recebido por carro vendido");
        double valorPorCarroVendido = teclado.nextDouble();
        
        double valorTotalPorCarros = carrosVendidos * valorPorCarroVendido;
        double comissao = (valorTotalPorCarros * 5) / 100;
        
        double salarioFinal = salarioFixo + valorTotalPorCarros + comissao;
        System.out.println("O salario final é: "+salarioFinal);
        
//acho q eu errei alguma coisa por falta de interpretação ;-;

    }
}
