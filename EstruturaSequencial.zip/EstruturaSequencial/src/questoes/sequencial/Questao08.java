/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao08 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o custo de fábrica");
        double custFab = teclado.nextDouble();
        
        double percentDist = (custFab * 28) / 100;
        double impostos = (custFab * 45) / 100;
        
        double precoFinal = custFab + percentDist + impostos;
        System.out.println("O preço final é: "+precoFinal);
    }
}
