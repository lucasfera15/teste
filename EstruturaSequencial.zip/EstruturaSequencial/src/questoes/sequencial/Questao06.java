/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.sequencial;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao06 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a quantidade de eleitores");
        double eleitores = teclado.nextDouble();
        System.out.println("Digite o número de votos brancos");
        double votosBrancos = teclado.nextDouble();
        System.out.println("Digite o número de votos nulos");
        double votosNulos = teclado.nextDouble();
        System.out.println("Digite o número de votos válidos");
        double votosValidos = teclado.nextDouble();
        
        double percentBranco = (votosBrancos / eleitores) * 100;
        double percentNulo = (votosNulos / eleitores) * 100;
        double percentValido = (votosValidos / eleitores) * 100;
        
        //por algum motivo,o calculo so deu certo pq os atributos de votos tinham q ser do tipo double
        //se fossem int,o resultado dava zero...isso n era pra acontecer ;-;
        
        System.out.println("A % de votos brancos foi de: "+percentBranco);
        System.out.println("A % de votos nulos foi de: "+percentNulo);
        System.out.println("A % de votos válidos foi de: "+percentValido);
    }
}
