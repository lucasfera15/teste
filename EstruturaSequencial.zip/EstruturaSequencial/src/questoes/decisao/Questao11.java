/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao11 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite um valor");
        double num = teclado.nextDouble();
        
        if(num > 10){
            System.out.println("É maior que 10!");
        }else if(num < 10){
            System.out.println("É menor que 10!");
        }
    }
}
