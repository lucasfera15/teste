/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao14 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a nota 1");
        double nota1 = teclado.nextDouble();
        System.out.println("Digite a nota 2");
        double nota2 = teclado.nextDouble();
        System.out.println("Digite a nota 3");
        double nota3 = teclado.nextDouble();
        
        double media = (nota1+nota2+nota3)/3;
        
        if(media >= 7){
            System.out.println("Aprovado!");
        }else if(media >= 4){
            System.out.println("Recuperação!");
        }else{
            System.out.println("Reprovado!");
        }
    }
}
