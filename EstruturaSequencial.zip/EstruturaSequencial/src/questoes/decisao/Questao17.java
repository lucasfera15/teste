/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

//import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao17 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        //double[] valores = {0,1,2};
        
        System.out.println("Digite o valor A");
        //valores[0] = teclado.nextDouble();
        double A = teclado.nextDouble();
        System.out.println("Digite o valor B");
        //valores[1] = teclado.nextDouble();
        double B = teclado.nextDouble();
        System.out.println("Digite o valor C");
        //valores[2] = teclado.nextDouble();
        double C = teclado.nextDouble();
        
        //Arrays.sort(valores);
        //System.out.println(Arrays.toString(valores));
        
        double menor = 0;
        double meio = 0;
        double maior = 0;
        
        if(A > B && A > C){
            maior = A;
            if(B > C){
                meio = B;
                menor = C;
            }else{
                meio = C;
                menor = B;
            }
        }
        if(B > A && B > C){
            maior = B;
            if(A > C){
                meio = A;
                menor = C;
            }else{
                meio = C;
                menor = A;
            }
        }
        if(C > B && C > A){
            maior = C;
            if(B > A){
                meio = B;
                menor = A;
            }else{
                meio = A;
                menor = B;
            }
        }
        
        System.out.println("Em ordem: "+menor+" "+meio+" "+maior);
    }
}
