/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao18 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite as horas trabalhadas no mês");
        double horasNoMes = teclado.nextDouble();
        System.out.println("Digite o salário por hora");
        double salarioHora = teclado.nextDouble();
        
        double salarioTotal;
        double horasExtras;
        double valorHoraExtra;
        if(horasNoMes > 160){
            horasExtras = horasNoMes - 160;
            valorHoraExtra = ((salarioHora * 50) / 100) * horasExtras;
            salarioTotal = (salarioHora + valorHoraExtra) * horasNoMes;
        }else{
            salarioTotal = salarioHora * horasNoMes;
        }
        
        System.out.println("O salário total é: "+salarioTotal);
        //Provalvemente tem algo errado ai ;-;
    }
}
