/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao13 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite a quantidade de maçãs");
        double quant = teclado.nextDouble();
        
        if(quant < 12){
            System.out.println("O preço final é: "+ (quant * 1.30));
        }else{
            System.out.println("O preço final é: "+ quant);
        }
    }
}
