/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao20 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o salário fixo");
        double salFixo = teclado.nextDouble();
        System.out.println("Digite o valor das vendas");
        double valVendas = teclado.nextDouble();

        double salarioFinal;
        
        if(valVendas <= 1500){
            salarioFinal = salFixo + (valVendas * 3 / 100);
        }else{
            salarioFinal = salFixo + (valVendas * 5 / 100);
        }
        
        System.out.println("O salário total é de: "+salarioFinal);
    }
}
