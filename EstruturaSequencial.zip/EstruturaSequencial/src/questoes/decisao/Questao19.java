/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao19 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o número da conta");
        int numConta = teclado.nextInt();
        System.out.println("Digite o saldo");
        double saldo = teclado.nextDouble();
        System.out.println("Digite o débito");
        double debito = teclado.nextDouble();
        System.out.println("Digite o crédito");
        double credito = teclado.nextDouble();
        
        double saldoAtual = saldo - debito + credito;
        System.out.println("O saldo atual da conta "+numConta+" é: "+saldoAtual);
        
        if(saldoAtual >= 0){
            System.out.println("Saldo Positivo");
        }else{
            System.out.println("Saldo Negativo");
        }
    }
}
