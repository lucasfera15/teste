/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questoes.decisao;

import java.util.Scanner;

/**
 *
 * @author LUCAS-PC
 */
public class Questao15 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Digite o ano atual");
        int anoAtual = teclado.nextInt();
        System.out.println("Digite o ano de nascimento");
        int anoNascimento = teclado.nextInt();
        
        int idade = anoAtual - anoNascimento;
        System.out.println("Sua idade é: "+idade);
        if(idade >= 16){
            System.out.println("Pode votar!");
        }else{
            System.out.println("Não pode votar!");
        }
    }
}
