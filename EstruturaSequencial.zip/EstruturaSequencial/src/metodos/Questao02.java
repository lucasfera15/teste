/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

import java.util.Arrays;

/**
 *
 * @author LUCAS-PC
 */
public class Questao02 {
    public static void main(String[] args) {
        
    }
    public static void somarVetor(double[] valores){
        double soma = 0;
        
        for (int i = 0; i < valores.length; i++) {
           soma += i;
        }
    }
}
